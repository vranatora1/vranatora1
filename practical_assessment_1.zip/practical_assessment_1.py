#!/usr/bin/env python3
#compute the average of a collection of values entered by the user.

#The user will enter 0 to indicate the end of input.

#Initialize count and total to 0
count = 0 
total = 0



   

# Read the first value
value = float (input ("Enter a number : "))

# While the value is not 0  
while value != 0 :

    # Add the value total
    total = total + value 

    # Increase the count of how many values were entered   
    count = count + 1  

     # Read the next value 
    value = float(input( "Enter another number :  "))

# Display an appropriate error message if no value were entered 
    if count == 0 : 
      print("No values were entered . ")
    else : 
# Compute the average and display the result 
        average = total / count
        print(" The average of those numbers is " , average)
      